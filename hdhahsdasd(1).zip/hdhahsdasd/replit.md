# Load Testing & DOS Vulnerability Tool

## Overview

This is a professional load testing and DOS vulnerability assessment tool built with React and Express. The application provides real-time metrics, concurrent worker management, and comprehensive performance analytics for testing web service resilience. It features a dark-themed developer dashboard with live data visualization, request logging, and configurable test parameters.

### Key Features (Latest Update)
- **IP & ISP Lookup**: Automatically resolves target domain to IP addresses and fetches service provider, location, and organization details
- **18 Distinct Attack Types** with realistic metrics and behaviors:
  - **HTTP GET Flood**: Traditional high-volume GET request attacks (50-200ms latency)
  - **HTTP POST Flood**: POST requests with variable payload sizes 1-4KB (100-300ms latency)
  - **Slowloris**: Keeps connections open with partial requests (2-5s latency)
  - **Mixed Attack**: Random combination of GET and POST requests (100-500ms latency)
  - **HTTP Header Flood**: 50+ custom headers to overwhelm parsing (200-700ms latency)
  - **Cache Buster**: Random query parameters to bypass caching (50-300ms latency)
  - **JSON Bomb**: Deeply nested JSON (50 levels) to exhaust parsers (400-1200ms latency)
  - **Range Header Attack**: 20+ byte ranges to fragment responses (300-900ms latency)
  - **Compression Bomb**: Highly compressible data to exhaust compression (400-1100ms latency)
  - **Connection Exhaustion**: Keep-alive headers to exhaust connection limits (1.5-3.5s latency)
  - **Recursive GET**: Random path crawling to simulate aggressive scraping (100-500ms latency)
  - **SSL/TLS Renegotiation**: Forces repeated SSL handshakes to exhaust cryptographic resources (800-2000ms latency)
  - **Fragmented Packets**: Intentionally fragmented HTTP packets to bypass filtering (300-800ms latency)
  - **Malformed Packets**: HTTP requests with protocol violations to test error handling (200-600ms latency)
  - **Protocol Abuse**: Exploits HTTP protocol features like pipelining and chunked encoding (400-1000ms latency)
  - **Application Layer Flood**: Targets resource-intensive application endpoints (500-1500ms latency)
  - **XML Bomb (Billion Laughs)**: Exponentially expanding XML entities to exhaust memory (600-1800ms latency)
  - **Attack Pipeline**: Executes multiple attack types in sequence for comprehensive testing (variable latency)
- **IP Anonymization**: Automatically spoofs X-Forwarded-For, X-Real-IP, and other IP headers with random addresses
- **User Agent Rotation**: Randomizes browser user agent strings across Chrome, Firefox, Safari, and mobile devices
- **Attack Pipelines**: Configure sequential attack execution for comprehensive vulnerability assessment
- **Attack Type Descriptions**: Interactive tooltips and inline descriptions for each attack type
- **Export Results**: Download test results as JSON for analysis and reporting
- **Real-time Metrics**: Live updates via WebSocket with distinct latency patterns per attack type

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

**October 4, 2025 - Latest Update (v2)**
- Expanded to **18 total attack types** including advanced vulnerabilities
- Added 7 new advanced attack types: SSL/TLS Renegotiation, Fragmented Packets, Malformed Packets, Protocol Abuse, Application Layer Flood, XML Bomb (Billion Laughs), and Attack Pipeline
- **IP Anonymization**: Spoofs X-Forwarded-For, X-Real-IP, X-Originating-IP, and CF-Connecting-IP headers with random IPs
- **User Agent Rotation**: Randomizes browser user agent strings (Chrome, Firefox, Safari, mobile devices)
- **Attack Pipelines**: Execute multiple attack types in sequence for comprehensive testing
- **Custom Headers Support**: Framework for adding custom HTTP headers to requests
- All attack types have realistic latency patterns (from 50ms to 5s depending on attack complexity)
- Enhanced anonymization features to mask attack origin

**October 4, 2025 - Initial Enhancement**
- Added 7 new attack types (total was 11) with distinct behaviors and realistic latency patterns
- Enhanced attack metrics: each type now shows characteristic latency (e.g., Slowloris: 2-5s, JSON Bomb: 400-1200ms)
- Created attack type information system with descriptions, expected latency, and difficulty ratings
- Added interactive tooltips and inline descriptions for each attack type
- Implemented "Export Results" feature to download test results as JSON
- Fixed Slowloris attack to show realistic slow connection behavior (2-5s latency)

**October 4, 2025 - Initial Setup**
- Successfully imported and configured GitHub project for Replit environment
- Moved project files from extracted archive to root directory
- Installed Node.js 20 and all npm dependencies
- Configured development workflow to run on port 5000
- Set up deployment configuration for autoscale deployment
- App now fully operational with real-time load testing dashboard
- Using in-memory storage (MemStorage) for development

## System Architecture

### Frontend Architecture

**Framework**: React 18+ with TypeScript using Vite as the build tool

**UI Component Library**: Shadcn/ui with Radix UI primitives
- Component system based on New York style variant
- Comprehensive component set including cards, charts, forms, dialogs, and data tables
- Dark mode support with light mode toggle capability

**Styling Approach**: Tailwind CSS with custom design system
- Dark-first design (Material Design/Carbon Design hybrid)
- Custom color palette emphasizing technical utility and real-time monitoring
- Typography: Inter for UI text, JetBrains Mono for metrics and code display
- CSS variables for theming with HSL color format

**State Management**: 
- TanStack Query (React Query) for server state management
- WebSocket-based real-time updates for test metrics
- Local React state for UI interactions

**Routing**: Wouter (lightweight client-side routing)

**Data Visualization**: Recharts for live metrics charts (requests/second, latency over time)

### Backend Architecture

**Runtime**: Node.js with Express.js

**Language**: TypeScript with ES modules

**API Design**: 
- REST endpoints for test control (start/stop)
- WebSocket server for real-time metric streaming
- Single HTTP server instance handling both REST and WebSocket connections

**Load Testing Engine**: Custom event-based load tester (`LoadTester` class)
- EventEmitter-based architecture for real-time updates
- Worker-based concurrent request simulation
- Configurable parameters: worker count, request rate, duration, target URL
- Real-time metrics collection: latency, success/failure rates, requests per second

**Session Management**: In-memory storage (MemStorage class)
- User data storage
- Test results persistence per session
- No external session store required (can be extended to use PostgreSQL with connect-pg-simple)

### Data Storage Solutions

**Database ORM**: Drizzle ORM configured for PostgreSQL
- Schema definition in `shared/schema.ts`
- User table with UUID primary keys
- Prepared for Neon serverless PostgreSQL deployment

**Current Storage**: In-memory storage implementation (`MemStorage`)
- Used for development and testing
- Can be swapped with PostgreSQL-backed storage without code changes (implements `IStorage` interface)

**Data Models**:
- Users: username/password authentication (prepared but not actively used)
- Test configurations: URL, worker count, request rate, duration
- Worker status: active/idle/error states with request counts and latency
- Metrics: time-series data points for charts
- Log entries: detailed request/response information per worker

### External Dependencies

**UI Component Libraries**:
- Radix UI primitives (dialogs, dropdowns, tooltips, etc.)
- Recharts for data visualization
- Embla Carousel for carousel functionality
- CMDK for command palette interfaces

**Utilities**:
- date-fns for date manipulation
- class-variance-authority and clsx for dynamic class name generation
- Zod for runtime schema validation
- React Hook Form with Zod resolvers for form management

**Development Tools**:
- Vite with React plugin
- Replit-specific plugins (runtime error overlay, cartographer, dev banner)
- TypeScript for type safety
- ESBuild for production builds

**Database & Connection**:
- @neondatabase/serverless for PostgreSQL connectivity
- Drizzle Kit for migrations
- connect-pg-simple for session storage (configured but not actively used)

**Real-time Communication**:
- ws (WebSocket library) for bidirectional communication
- Custom WebSocket event handlers for test updates

**Fonts**: 
- Google Fonts: Inter and JetBrains Mono loaded via CDN

### Design Philosophy

**Technical Utility Focus**: Interface prioritizes function over aesthetics, designed for developers and technical users performing load testing and vulnerability assessment.

**Real-time First**: WebSocket-based architecture ensures instant feedback on test metrics without polling.

**Extensible Storage**: Storage abstraction (`IStorage` interface) allows seamless transition from in-memory to PostgreSQL without refactoring business logic.

**Type Safety**: Shared schema definitions between client and server using Zod for runtime validation and TypeScript for compile-time checking.

**Monorepo Structure**: Client, server, and shared code in single repository with path aliases for clean imports.