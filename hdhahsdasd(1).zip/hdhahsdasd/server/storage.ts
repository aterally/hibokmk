import { type User, type InsertUser, type TestResults } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  saveTestResults(sessionId: string, results: TestResults): Promise<void>;
  getTestResults(sessionId: string): Promise<TestResults | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private testResults: Map<string, TestResults>;

  constructor() {
    this.users = new Map();
    this.testResults = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async saveTestResults(sessionId: string, results: TestResults): Promise<void> {
    this.testResults.set(sessionId, results);
  }

  async getTestResults(sessionId: string): Promise<TestResults | undefined> {
    return this.testResults.get(sessionId);
  }
}

export const storage = new MemStorage();
