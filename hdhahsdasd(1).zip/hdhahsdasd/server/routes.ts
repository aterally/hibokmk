import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { loadTester } from "./loadTester";
import { testConfigSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  const clients = new Set<WebSocket>();

  wss.on("connection", (ws) => {
    console.log("WebSocket client connected");
    clients.add(ws);

    ws.send(JSON.stringify({
      type: "status",
      isRunning: loadTester.getIsRunning(),
      results: loadTester.getResults(),
    }));

    ws.on("close", () => {
      console.log("WebSocket client disconnected");
      clients.delete(ws);
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
      clients.delete(ws);
    });
  });

  loadTester.on("update", (results) => {
    const message = JSON.stringify({
      type: "update",
      results,
    });

    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  });

  loadTester.on("stopped", () => {
    const message = JSON.stringify({
      type: "stopped",
      results: loadTester.getResults(),
    });

    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  });

  app.post("/api/test/start", async (req, res) => {
    try {
      const config = testConfigSchema.parse(req.body);
      
      if (loadTester.getIsRunning()) {
        return res.status(400).json({ error: "Test is already running" });
      }

      try {
        const url = new URL(config.targetUrl);
        if (!['http:', 'https:'].includes(url.protocol)) {
          return res.status(400).json({ error: "Only HTTP and HTTPS protocols are allowed" });
        }
      } catch (error) {
        return res.status(400).json({ error: "Invalid target URL" });
      }

      await loadTester.start(config);

      res.json({ 
        success: true, 
        message: "Load test started",
        config,
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/test/stop", async (req, res) => {
    try {
      loadTester.stop();
      res.json({ 
        success: true, 
        message: "Load test stopped",
        results: loadTester.getResults(),
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/test/status", async (req, res) => {
    try {
      res.json({
        isRunning: loadTester.getIsRunning(),
        results: loadTester.getResults(),
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  return httpServer;
}
