import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const testConfigSchema = z.object({
  targetUrl: z.string().url(),
  workerCount: z.number().min(1).max(100),
  requestRate: z.number().min(1),
  duration: z.number().min(1),
  attackType: z.enum([
    "http_flood", 
    "post_flood", 
    "slowloris", 
    "mixed",
    "http_header_flood",
    "cache_buster",
    "json_bomb",
    "range_header_attack",
    "compression_bomb",
    "connection_exhaustion",
    "recursive_get",
    "ssl_renegotiation",
    "fragmented_packets",
    "malformed_packets",
    "protocol_abuse",
    "application_layer_flood",
    "xml_bomb",
    "pipeline"
  ]).default("http_flood"),
  pipeline: z.array(z.string()).optional(),
  useProxy: z.boolean().default(false),
  proxyUrl: z.string().optional(),
  anonymizeIP: z.boolean().default(false),
  rotateUserAgent: z.boolean().default(false),
  customHeaders: z.record(z.string()).optional(),
});

export type TestConfig = z.infer<typeof testConfigSchema>;

export const targetInfoSchema = z.object({
  hostname: z.string(),
  ipAddresses: z.array(z.string()),
  isp: z.string().optional(),
  country: z.string().optional(),
  city: z.string().optional(),
  org: z.string().optional(),
});

export type TargetInfo = z.infer<typeof targetInfoSchema>;

export const workerStatusSchema = z.object({
  id: z.number(),
  status: z.enum(["active", "idle", "error"]),
  requests: z.number(),
  latency: z.number(),
});

export type WorkerStatus = z.infer<typeof workerStatusSchema>;

export const logEntrySchema = z.object({
  id: z.string(),
  timestamp: z.string(),
  method: z.string(),
  url: z.string(),
  status: z.number(),
  latency: z.number(),
  workerId: z.number(),
});

export type LogEntry = z.infer<typeof logEntrySchema>;

export const metricDataPointSchema = z.object({
  time: z.string(),
  requests: z.number(),
  latency: z.number(),
});

export type MetricDataPoint = z.infer<typeof metricDataPointSchema>;

export const testResultsSchema = z.object({
  totalRequests: z.number(),
  successRate: z.number(),
  avgLatency: z.number(),
  currentRps: z.number(),
  failedRequests: z.number(),
  workers: z.array(workerStatusSchema),
  logs: z.array(logEntrySchema),
  chartData: z.array(metricDataPointSchema),
  latencyData: z.array(metricDataPointSchema),
  targetInfo: targetInfoSchema.optional(),
});

export type TestResults = z.infer<typeof testResultsSchema>;
