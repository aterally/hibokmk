import ConfigurationPanel, { TestConfig } from "@/components/ConfigurationPanel";
import MetricsCard from "@/components/MetricsCard";
import WorkerStatusGrid from "@/components/WorkerStatusGrid";
import RequestLogStream from "@/components/RequestLogStream";
import LiveMetricsChart from "@/components/LiveMetricsChart";
import TargetInfoCard from "@/components/TargetInfoCard";
import ThemeToggle from "@/components/ThemeToggle";
import { Activity, CheckCircle2, Clock, XCircle, Zap, Download } from "lucide-react";
import { useLoadTest } from "@/hooks/useLoadTest";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { isRunning, results, startTest, stopTest } = useLoadTest();
  const { toast } = useToast();

  const handleStart = async (config: TestConfig) => {
    try {
      await startTest(config);
      toast({
        title: "Load test started",
        description: `Testing ${config.targetUrl} with ${config.workerCount} workers`,
      });
    } catch (error: any) {
      toast({
        title: "Error starting test",
        description: error.message || "Failed to start load test",
        variant: "destructive",
      });
    }
  };

  const handleStop = async () => {
    try {
      await stopTest();
      toast({
        title: "Load test stopped",
        description: `Completed ${results.totalRequests} requests`,
      });
    } catch (error: any) {
      toast({
        title: "Error stopping test",
        description: error.message || "Failed to stop load test",
        variant: "destructive",
      });
    }
  };

  const handleDownloadResults = () => {
    const exportData = {
      timestamp: new Date().toISOString(),
      results,
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json',
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `load-test-results-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Results exported",
      description: "Test results downloaded as JSON",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/50 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary text-primary-foreground">
                <Zap className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Load Tester</h1>
                <p className="text-xs text-muted-foreground">DOS Vulnerability Testing</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownloadResults}
                disabled={results.totalRequests === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                Export Results
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <ConfigurationPanel
              onStart={handleStart}
              onStop={handleStop}
              isRunning={isRunning}
            />
            {results.targetInfo && <TargetInfoCard targetInfo={results.targetInfo} />}
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MetricsCard
                title="Total Requests"
                value={results.totalRequests.toLocaleString()}
                icon={Activity}
                colorClass="text-chart-1"
              />
              <MetricsCard
                title="Requests/sec"
                value={results.currentRps.toLocaleString()}
                icon={Zap}
                colorClass="text-chart-1"
              />
              <MetricsCard
                title="Success Rate"
                value={`${results.successRate.toFixed(1)}%`}
                icon={CheckCircle2}
                colorClass="text-chart-2"
              />
              <MetricsCard
                title="Avg Latency"
                value={`${results.avgLatency}ms`}
                icon={Clock}
                colorClass="text-chart-3"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <LiveMetricsChart
                data={results.chartData}
                title="Requests per Second"
                dataKey="requests"
                yAxisLabel="req/s"
              />
              <LiveMetricsChart
                data={results.latencyData}
                title="Response Latency"
                dataKey="latency"
                yAxisLabel="ms"
              />
            </div>

            {results.workers.length > 0 && <WorkerStatusGrid workers={results.workers} />}
            
            {results.logs.length > 0 && <RequestLogStream logs={results.logs} />}
          </div>
        </div>
      </main>
    </div>
  );
}
