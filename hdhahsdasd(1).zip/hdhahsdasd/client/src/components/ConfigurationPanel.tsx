import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Switch } from "@/components/ui/switch";
import { Play, Square, Info } from "lucide-react";
import { useState } from "react";
import { attackTypeInfo, type AttackTypeKey } from "@/lib/attackTypes";

interface ConfigurationPanelProps {
  onStart: (config: TestConfig) => void;
  onStop: () => void;
  isRunning: boolean;
}

export type AttackType = "http_flood" | "post_flood" | "slowloris" | "mixed" | "http_header_flood" | "cache_buster" | "json_bomb" | "range_header_attack" | "compression_bomb" | "connection_exhaustion" | "recursive_get" | "ssl_renegotiation" | "fragmented_packets" | "malformed_packets" | "protocol_abuse" | "application_layer_flood" | "xml_bomb" | "pipeline";

export interface TestConfig {
  targetUrl: string;
  workerCount: number;
  requestRate: number;
  duration: number;
  attackType: AttackType;
  pipeline?: string[];
  useProxy?: boolean;
  proxyUrl?: string;
  anonymizeIP?: boolean;
  rotateUserAgent?: boolean;
  customHeaders?: Record<string, string>;
}

export default function ConfigurationPanel({ onStart, onStop, isRunning }: ConfigurationPanelProps) {
  const [targetUrl, setTargetUrl] = useState("https://example.com");
  const [workerCount, setWorkerCount] = useState([25]);
  const [requestRate, setRequestRate] = useState("100");
  const [duration, setDuration] = useState("60");
  const [attackType, setAttackType] = useState<AttackType>("http_flood");
  const [anonymizeIP, setAnonymizeIP] = useState(false);
  const [rotateUserAgent, setRotateUserAgent] = useState(false);

  const handleStart = () => {
    onStart({
      targetUrl,
      workerCount: workerCount[0],
      requestRate: parseInt(requestRate) || 100,
      duration: parseInt(duration) || 60,
      attackType,
      anonymizeIP,
      rotateUserAgent,
      pipeline: attackType === "pipeline" ? ["http_flood", "post_flood", "slowloris"] : undefined,
    });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-4">
        <CardTitle className="text-lg">Configuration</CardTitle>
        <Badge
          variant={isRunning ? "default" : "secondary"}
          className={isRunning ? "bg-chart-2 text-chart-2-foreground" : ""}
          data-testid="badge-test-status"
        >
          {isRunning ? "Running" : "Idle"}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="target-url" className="text-sm font-medium">
            Target URL
          </Label>
          <Input
            id="target-url"
            type="url"
            placeholder="https://example.com"
            value={targetUrl}
            onChange={(e) => setTargetUrl(e.target.value)}
            className="font-mono text-sm"
            disabled={isRunning}
            data-testid="input-target-url"
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="worker-count" className="text-sm font-medium">
              Worker Count
            </Label>
            <span className="font-mono text-sm font-semibold" data-testid="text-worker-count">
              {workerCount[0]}
            </span>
          </div>
          <Slider
            id="worker-count"
            min={1}
            max={100}
            step={1}
            value={workerCount}
            onValueChange={setWorkerCount}
            disabled={isRunning}
            data-testid="slider-worker-count"
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="attack-type" className="text-sm font-medium">
              Attack Type
            </Label>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="text-sm">{attackTypeInfo[attackType as AttackTypeKey].description}</p>
                  <div className="mt-2 flex gap-2 text-xs">
                    <Badge variant="outline">Expected: {attackTypeInfo[attackType as AttackTypeKey].expectedLatency}</Badge>
                    <Badge variant="outline">Difficulty: {attackTypeInfo[attackType as AttackTypeKey].difficulty}</Badge>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Select value={attackType} onValueChange={(value) => setAttackType(value as AttackType)} disabled={isRunning}>
            <SelectTrigger id="attack-type" data-testid="select-attack-type">
              <SelectValue placeholder="Select attack type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="http_flood">HTTP GET Flood</SelectItem>
              <SelectItem value="post_flood">HTTP POST Flood</SelectItem>
              <SelectItem value="slowloris">Slowloris (Slow Connection)</SelectItem>
              <SelectItem value="mixed">Mixed Attack (GET + POST)</SelectItem>
              <SelectItem value="http_header_flood">HTTP Header Flood</SelectItem>
              <SelectItem value="cache_buster">Cache Buster (Random Params)</SelectItem>
              <SelectItem value="json_bomb">JSON Bomb (Deep Nesting)</SelectItem>
              <SelectItem value="range_header_attack">Range Header Attack</SelectItem>
              <SelectItem value="compression_bomb">Compression Bomb</SelectItem>
              <SelectItem value="connection_exhaustion">Connection Exhaustion</SelectItem>
              <SelectItem value="recursive_get">Recursive GET (Path Crawl)</SelectItem>
              <SelectItem value="ssl_renegotiation">SSL/TLS Renegotiation</SelectItem>
              <SelectItem value="fragmented_packets">Fragmented Packets</SelectItem>
              <SelectItem value="malformed_packets">Malformed Packets</SelectItem>
              <SelectItem value="protocol_abuse">Protocol Abuse</SelectItem>
              <SelectItem value="application_layer_flood">Application Layer Flood</SelectItem>
              <SelectItem value="xml_bomb">XML Bomb (Billion Laughs)</SelectItem>
              <SelectItem value="pipeline">Attack Pipeline (Multi-Type)</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground mt-1">
            {attackTypeInfo[attackType as AttackTypeKey].description}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="request-rate" className="text-sm font-medium">
              Requests/sec
            </Label>
            <Input
              id="request-rate"
              type="number"
              value={requestRate}
              onChange={(e) => setRequestRate(e.target.value)}
              className="font-mono"
              disabled={isRunning}
              data-testid="input-request-rate"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="duration" className="text-sm font-medium">
              Duration (s)
            </Label>
            <Input
              id="duration"
              type="number"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              className="font-mono"
              disabled={isRunning}
              data-testid="input-duration"
            />
          </div>
        </div>

        <div className="space-y-3 pt-2 border-t">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="anonymize-ip" className="text-sm font-medium">
                Anonymize IP
              </Label>
              <p className="text-xs text-muted-foreground">
                Spoofs X-Forwarded-For and other IP headers
              </p>
            </div>
            <Switch
              id="anonymize-ip"
              checked={anonymizeIP}
              onCheckedChange={setAnonymizeIP}
              disabled={isRunning}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="rotate-user-agent" className="text-sm font-medium">
                Rotate User Agent
              </Label>
              <p className="text-xs text-muted-foreground">
                Randomizes browser user agent strings
              </p>
            </div>
            <Switch
              id="rotate-user-agent"
              checked={rotateUserAgent}
              onCheckedChange={setRotateUserAgent}
              disabled={isRunning}
            />
          </div>
        </div>

        <div className="flex gap-3 pt-2">
          {!isRunning ? (
            <Button
              onClick={handleStart}
              className="flex-1"
              size="lg"
              data-testid="button-start-test"
            >
              <Play className="h-4 w-4 mr-2" />
              Start Test
            </Button>
          ) : (
            <Button
              onClick={onStop}
              variant="destructive"
              className="flex-1"
              size="lg"
              data-testid="button-stop-test"
            >
              <Square className="h-4 w-4 mr-2" />
              Stop Test
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
