import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Globe, MapPin, Network, Building } from "lucide-react";

interface TargetInfo {
  hostname: string;
  ipAddresses: string[];
  isp?: string;
  country?: string;
  city?: string;
  org?: string;
}

interface TargetInfoCardProps {
  targetInfo?: TargetInfo;
}

export default function TargetInfoCard({ targetInfo }: TargetInfoCardProps) {
  if (!targetInfo) {
    return null;
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Network className="h-4 w-4" />
          Target Information
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Globe className="h-3 w-3" />
            <span>Hostname</span>
          </div>
          <p className="font-mono text-sm font-medium">{targetInfo.hostname}</p>
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Network className="h-3 w-3" />
            <span>IP Address{targetInfo.ipAddresses.length > 1 ? 'es' : ''}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {targetInfo.ipAddresses.map((ip, index) => (
              <code key={index} className="px-2 py-1 bg-muted rounded text-xs font-mono">
                {ip}
              </code>
            ))}
          </div>
        </div>

        {targetInfo.isp && (
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Building className="h-3 w-3" />
              <span>Service Provider</span>
            </div>
            <p className="text-sm font-medium">{targetInfo.isp}</p>
          </div>
        )}

        {(targetInfo.country || targetInfo.city) && (
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" />
              <span>Location</span>
            </div>
            <p className="text-sm font-medium">
              {[targetInfo.city, targetInfo.country].filter(Boolean).join(', ')}
            </p>
          </div>
        )}

        {targetInfo.org && (
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Building className="h-3 w-3" />
              <span>Organization</span>
            </div>
            <p className="text-sm font-medium">{targetInfo.org}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
