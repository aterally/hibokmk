import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export interface WorkerStatus {
  id: number;
  status: "active" | "idle" | "error";
  requests: number;
  latency: number;
}

interface WorkerStatusGridProps {
  workers: WorkerStatus[];
}

export default function WorkerStatusGrid({ workers }: WorkerStatusGridProps) {
  const getStatusColor = (status: WorkerStatus["status"]) => {
    switch (status) {
      case "active":
        return "bg-chart-2 text-chart-2-foreground";
      case "idle":
        return "";
      case "error":
        return "bg-destructive text-destructive-foreground";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Worker Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {workers.map((worker) => (
            <div
              key={worker.id}
              className="flex flex-col gap-2 p-3 rounded-md border bg-card hover-elevate"
              data-testid={`worker-card-${worker.id}`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-muted-foreground">
                  #{worker.id}
                </span>
                <Badge
                  variant={worker.status === "active" ? "default" : "secondary"}
                  className={`text-xs ${getStatusColor(worker.status)}`}
                  data-testid={`worker-status-${worker.id}`}
                >
                  {worker.status === "active" && (
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-current animate-pulse mr-1" />
                  )}
                  {worker.status}
                </Badge>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Reqs</span>
                  <span className="font-mono font-semibold">{worker.requests}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Latency</span>
                  <span className="font-mono font-semibold">{worker.latency}ms</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
