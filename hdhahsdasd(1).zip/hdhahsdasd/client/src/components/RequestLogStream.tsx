import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useEffect, useRef } from "react";

export interface LogEntry {
  id: string;
  timestamp: string;
  method: string;
  url: string;
  status: number;
  latency: number;
  workerId: number;
}

interface RequestLogStreamProps {
  logs: LogEntry[];
}

export default function RequestLogStream({ logs }: RequestLogStreamProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return "text-chart-2";
    if (status >= 400 && status < 500) return "text-chart-3";
    if (status >= 500) return "text-chart-4";
    return "text-muted-foreground";
  };

  return (
    <Card className="flex flex-col h-full">
      <CardHeader>
        <CardTitle className="text-lg">Request Log</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-0">
        <ScrollArea className="h-[400px] w-full rounded-md border bg-muted/20" data-testid="log-stream">
          <div ref={scrollRef} className="p-4 font-mono text-xs space-y-1">
            {logs.length === 0 ? (
              <div className="text-muted-foreground">No requests yet...</div>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="flex gap-2" data-testid={`log-entry-${log.id}`}>
                  <span className="text-muted-foreground">[{log.timestamp}]</span>
                  <span className="text-muted-foreground">W{log.workerId}</span>
                  <span className="font-semibold">{log.method}</span>
                  <span className="text-muted-foreground truncate flex-1">{log.url}</span>
                  <span className={`font-bold ${getStatusColor(log.status)}`}>
                    {log.status}
                  </span>
                  <span className="text-muted-foreground">{log.latency}ms</span>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
