import RequestLogStream from '../RequestLogStream';

export default function RequestLogStreamExample() {
  const logs = [
    {
      id: "1",
      timestamp: "10:23:45",
      method: "GET",
      url: "https://example.com/api/test",
      status: 200,
      latency: 145,
      workerId: 3,
    },
    {
      id: "2",
      timestamp: "10:23:45",
      method: "GET",
      url: "https://example.com/api/test",
      status: 200,
      latency: 132,
      workerId: 7,
    },
    {
      id: "3",
      timestamp: "10:23:46",
      method: "GET",
      url: "https://example.com/api/test",
      status: 429,
      latency: 89,
      workerId: 12,
    },
    {
      id: "4",
      timestamp: "10:23:46",
      method: "GET",
      url: "https://example.com/api/test",
      status: 500,
      latency: 2345,
      workerId: 5,
    },
  ];

  return <RequestLogStream logs={logs} />;
}
