import WorkerStatusGrid from '../WorkerStatusGrid';

export default function WorkerStatusGridExample() {
  const workers = Array.from({ length: 15 }, (_, i) => ({
    id: i + 1,
    status: i < 12 ? "active" : i === 14 ? "error" : "idle",
    requests: Math.floor(Math.random() * 500) + 100,
    latency: Math.floor(Math.random() * 200) + 50,
  })) as any;

  return <WorkerStatusGrid workers={workers} />;
}
