import LiveMetricsChart from '../LiveMetricsChart';

export default function LiveMetricsChartExample() {
  const data = Array.from({ length: 20 }, (_, i) => ({
    time: `${i}s`,
    requests: Math.floor(Math.random() * 500) + 800,
    latency: Math.floor(Math.random() * 100) + 100,
  }));

  return (
    <LiveMetricsChart
      data={data}
      title="Requests per Second"
      dataKey="requests"
      yAxisLabel="req/s"
    />
  );
}
