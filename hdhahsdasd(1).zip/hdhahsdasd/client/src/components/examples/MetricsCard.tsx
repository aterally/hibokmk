import MetricsCard from '../MetricsCard';
import { Activity } from 'lucide-react';

export default function MetricsCardExample() {
  return (
    <MetricsCard
      title="Requests/sec"
      value="1,243"
      subtitle="avg 1,180 req/s"
      icon={Activity}
      colorClass="text-chart-1"
    />
  );
}
