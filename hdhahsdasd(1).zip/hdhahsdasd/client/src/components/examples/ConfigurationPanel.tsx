import ConfigurationPanel from '../ConfigurationPanel';
import { useState } from 'react';

export default function ConfigurationPanelExample() {
  const [isRunning, setIsRunning] = useState(false);

  return (
    <ConfigurationPanel
      onStart={(config) => {
        console.log('Starting test with config:', config);
        setIsRunning(true);
      }}
      onStop={() => {
        console.log('Stopping test');
        setIsRunning(false);
      }}
      isRunning={isRunning}
    />
  );
}
