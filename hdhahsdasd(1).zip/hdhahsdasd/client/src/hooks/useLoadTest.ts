import { useState, useEffect, useCallback, useRef } from "react";
import { TestResults, TestConfig } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface WebSocketMessage {
  type: "status" | "update" | "stopped";
  isRunning?: boolean;
  results?: TestResults;
}

export function useLoadTest() {
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<TestResults>({
    totalRequests: 0,
    successRate: 0,
    avgLatency: 0,
    currentRps: 0,
    failedRequests: 0,
    workers: [],
    logs: [],
    chartData: [],
    latencyData: [],
  });

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const connectWebSocket = useCallback(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log("WebSocket connected");
      };

      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          
          if (message.type === "status" || message.type === "update") {
            if (message.isRunning !== undefined) {
              setIsRunning(message.isRunning);
            }
            if (message.results) {
              setResults(message.results);
            }
          } else if (message.type === "stopped") {
            setIsRunning(false);
            if (message.results) {
              setResults(message.results);
            }
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
        }
      };

      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
      };

      ws.onclose = () => {
        console.log("WebSocket disconnected");
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
        }
        reconnectTimeoutRef.current = setTimeout(() => {
          console.log("Reconnecting WebSocket...");
          connectWebSocket();
        }, 3000);
      };

      wsRef.current = ws;
    } catch (error) {
      console.error("Error creating WebSocket:", error);
    }
  }, []);

  useEffect(() => {
    connectWebSocket();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connectWebSocket]);

  const startTest = useCallback(async (config: TestConfig) => {
    try {
      await apiRequest("POST", "/api/test/start", config);
      setIsRunning(true);
    } catch (error) {
      console.error("Error starting test:", error);
      throw error;
    }
  }, []);

  const stopTest = useCallback(async () => {
    try {
      await apiRequest("POST", "/api/test/stop");
      setIsRunning(false);
    } catch (error) {
      console.error("Error stopping test:", error);
      throw error;
    }
  }, []);

  return {
    isRunning,
    results,
    startTest,
    stopTest,
  };
}
