# Design Guidelines: Load Testing & DOS Vulnerability Tool

## Design Approach
**System-Based Approach**: Material Design / Carbon Design hybrid  
**Rationale**: Technical utility tool requiring clear data visualization, real-time monitoring, and professional dashboard interface. Function and clarity prioritize over visual flair.

## Core Design Principles
- **Power & Control**: Interface conveys technical capability and precision
- **Real-time Clarity**: Instant visual feedback on test status and metrics
- **Professional Tool**: Dark-themed, developer-focused aesthetic
- **Data First**: Metrics and results are the visual focus

## Color Palette

**Dark Mode Primary** (Default):
- Background Base: 222 15% 8%
- Surface: 222 13% 12%
- Surface Elevated: 222 12% 16%
- Primary Accent: 210 100% 60% (Electric Blue - for active states)
- Success: 142 76% 45% (Active/Running indicators)
- Warning: 38 92% 50% (High load warnings)
- Danger: 0 84% 60% (DOS/Critical states)
- Text Primary: 0 0% 98%
- Text Secondary: 0 0% 65%

**Light Mode** (Optional toggle):
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Adjust all colors for light contrast

## Typography
- **Primary Font**: 'Inter' (Google Fonts) - clean, technical
- **Monospace**: 'JetBrains Mono' - for metrics, URLs, logs
- Hierarchy: 
  - Display: 2.5rem/bold (Dashboard titles)
  - Headers: 1.5rem/semibold (Section headers)
  - Body: 1rem/regular (Controls, labels)
  - Metrics: 1.25rem/medium monospace (Numbers, stats)
  - Code: 0.875rem/regular monospace (URLs, logs)

## Layout System
**Spacing Primitives**: Tailwind units 2, 4, 6, 8, 12, 16
- Consistent padding: p-6 for cards, p-8 for main sections
- Gap spacing: gap-4 for grids, gap-6 for major separations
- Max-width: max-w-7xl for dashboard container

## Component Library

### A. Dashboard Layout
- **Two-column grid**: Configuration panel (30%) + Live metrics (70%)
- Responsive: Stack to single column on mobile
- Fixed header with tool branding and quick actions

### B. Configuration Panel
- **Target URL input**: Large, prominent text field with validation
- **Worker Controls**: 
  - Worker count slider (1-100) with live number display
  - Request rate input (requests/second)
  - Duration/timeout settings
- **Attack Patterns dropdown**: GET flood, Slowloris simulation, etc.
- **Start/Stop buttons**: Large, color-coded (Success green/Danger red)
- Status badge showing current test state (Idle/Running/Stopped)

### C. Live Metrics Dashboard
- **Real-time graphs**: Line charts for requests/sec, response times
- **Worker Status Grid**: Cards showing individual worker states with pulse animations
- **Key Metrics Cards**: 
  - Total requests sent (large number display)
  - Success/failure rate (percentage with color coding)
  - Average response time (ms)
  - Server status (UP/DOWN with indicator)
- **Request Log Stream**: Terminal-style scrolling log with color-coded responses (2xx green, 4xx yellow, 5xx red)

### D. Results & Analysis Section
- **Summary cards** post-test: Peak RPS, Total duration, Success rate
- **Vulnerability Report**: Color-coded findings (Safe/Vulnerable/Critical)
- **Export options**: Download CSV/JSON of test results

## Navigation & Controls
- **Top bar**: Tool logo, active test indicator, settings gear, theme toggle
- **Sticky controls**: Configuration panel remains accessible while scrolling metrics
- **Quick actions**: One-click stop test (prominent emergency stop style)

## Visual Enhancements
### Status Indicators
- Pulsing dot animations for active workers (green pulse)
- Loading spinners for in-progress requests
- Progress bars for test duration countdown

### Data Visualization
- Gradient fills on line charts (transparent to accent color)
- Grid lines: subtle (10% opacity white/black)
- Smooth chart animations (transition-all duration-300)

### Interactive States
- Buttons: Subtle scale on hover (hover:scale-105), clear active states
- Cards: Border glow on hover (border-primary/20)
- Inputs: Focus ring with primary color, clear error states

## Accessibility
- All metrics have ARIA labels for screen readers
- Keyboard shortcuts for start/stop (Space/Esc)
- High contrast maintained across all color states
- Focus indicators visible on all interactive elements

## Images & Icons
**Icons**: Material Icons (via CDN)
- Play/Pause for test controls
- Warning/Alert icons for status
- Network/Cloud icons for connection states
- Chart/Analytics icons for metrics sections

**No hero images** - This is a functional dashboard tool, not a marketing page. Focus is entirely on interface controls and data display.

## Animations
**Minimal & Purposeful**:
- Pulse animation on active worker indicators (animate-pulse)
- Smooth number counting for live metrics (CountUp.js or similar)
- Chart data transitions (500ms ease-in-out)
- NO decorative animations - keep interface responsive and focused